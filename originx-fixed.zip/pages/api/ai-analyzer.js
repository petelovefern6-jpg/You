// ✅ /pages/api/ai-analyzer.js — was reading a snapshot file that never gets generated (always 404)
// Now pulls live data from visionary-batch so it actually works.
export default async function handler(req, res) {
  try {
    const proto = req.headers["x-forwarded-proto"] || "http";
    const base = `${proto}://${req.headers.host}`;
    const batchRes = await fetch(`${base}/api/visionary-batch?batch=1`).then((r) => r.json());
    const data = batchRes?.results || [];

    const buys = data
      .filter((x) => x.signal === "Buy")
      .sort((a, b) => (b.aiScore || 0) - (a.aiScore || 0))
      .slice(0, 20);
    const holds = data
      .filter((x) => x.signal === "Hold")
      .sort((a, b) => (b.rsi || 0) - (a.rsi || 0))
      .slice(0, 20);
    const sells = data
      .filter((x) => x.signal === "Sell")
      .sort((a, b) => (b.rsi || 0) - (a.rsi || 0))
      .slice(0, 20);

    res.status(200).json({ updated: new Date().toISOString(), buys, holds, sells });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
