// ✅ utils/trackAccuracy.js
// A real (not fabricated) feedback loop: every time the app shows a Buy/Sell
// signal, it's logged. Next time that symbol loads, we check whether the
// price actually moved the predicted direction, and tally a running
// accuracy score. This is what "improves over time" honestly means here —
// it does NOT retrain any model, it just shows you how reliable the
// technical-indicator signals have actually been.

const KEY = "originx_signal_history";
const MAX_ENTRIES = 500;

function load() {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

function save(entries) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(entries.slice(-MAX_ENTRIES)));
}

// Call whenever a fresh signal + price is shown for a symbol.
// Also resolves any older pending entries for the same symbol using the new price.
export function logSignal(symbol, signal, price) {
  if (!symbol || !price || signal === "Hold") return;
  const entries = load();

  // Resolve prior pending calls for this symbol against the new price
  const HOUR = 60 * 60 * 1000;
  const now = Date.now();
  for (const e of entries) {
    if (e.symbol === symbol && !e.resolved && now - e.ts > HOUR) {
      const movedUp = price > e.price;
      e.hit = e.signal === "Buy" ? movedUp : e.signal === "Sell" ? !movedUp : null;
      e.resolved = true;
      e.resolvedAt = now;
    }
  }

  // Log the new prediction (avoid spamming duplicates within the same hour)
  const recentDup = entries.find(
    (e) => e.symbol === symbol && !e.resolved && now - e.ts < HOUR
  );
  if (!recentDup) {
    entries.push({ symbol, signal, price, ts: now, resolved: false, hit: null });
  }

  save(entries);
}

export function getAccuracyStats() {
  const entries = load().filter((e) => e.resolved && e.hit !== null);
  const total = entries.length;
  const hits = entries.filter((e) => e.hit).length;
  const accuracy = total > 0 ? Math.round((hits / total) * 100) : null;
  return { total, hits, accuracy };
}
