import { useEffect, useState } from "react";
import { logSignal } from "../utils/trackAccuracy";

export default function MarketSection() {
  const [data, setData] = useState([]);

  const symbols = [
    "WULF","DNA","BYND","OSCR","BBAI","ACHR","PATH","MVIS","SES","KSCP",
    "CCCX","RKLB","ASTS","CRSP","SLDP","ENVX","SOFI","HASI","LWLG","SOUN",
    "AXTI","LAES","RXRX","NRGV","RIVN"
  ];

  const logoMap = {
    WULF:"terawulf.com", DNA:"ginkgobioworks.com", BYND:"beyondmeat.com",
    OSCR:"hioscar.com", BBAI:"bigbear.ai", ACHR:"archer.com", PATH:"uipath.com",
    MVIS:"microvision.com", SES:"ses.ai", KSCP:"knightscope.com", CCCX:"churchillcapitalcorp.com",
    RKLB:"rocketlabusa.com", ASTS:"ast-science.com", CRSP:"crisprtx.com", SLDP:"solidpowerbattery.com",
    ENVX:"enovix.com", SOFI:"sofi.com", HASI:"hannonarmstrong.com", LWLG:"lightwavelogic.com",
    SOUN:"soundhound.com", AXTI:"axt.com", LAES:"sealsq.com", RXRX:"recursion.com",
    NRGV:"energyvault.com", RIVN:"rivian.com"
  };

  const companyMap = {
    WULF:"TeraWulf Inc.", DNA:"Ginkgo Bioworks Holdings Inc.", BYND:"Beyond Meat Inc.",
    OSCR:"Oscar Health Inc.", BBAI:"BigBear.ai Holdings Inc.", ACHR:"Archer Aviation Inc.",
    PATH:"UiPath Inc.", MVIS:"MicroVision Inc.", SES:"SES AI Corporation",
    KSCP:"Knightscope Inc.", CCCX:"Churchill Capital Corp X", RKLB:"Rocket Lab USA Inc.",
    ASTS:"AST SpaceMobile Inc.", CRSP:"CRISPR Therapeutics AG", SLDP:"Solid Power Inc.",
    ENVX:"Enovix Corporation", SOFI:"SoFi Technologies Inc.",
    HASI:"Hannon Armstrong Sustainable Infrastructure Capital Inc.",
    LWLG:"Lightwave Logic Inc.", SOUN:"SoundHound AI Inc.",
    AXTI:"AXT Inc.", LAES:"SEALSQ Corp", RXRX:"Recursion Pharmaceuticals Inc.",
    NRGV:"Energy Vault Holdings Inc.", RIVN:"Rivian Automotive Inc."
  };

  // ✅ โหลดข้อมูลหุ้นทั้งหมด (พร้อม fallback ถ้าราคา 0)
  async function loadAll() {
    const cached = sessionStorage.getItem("originx-cache");
    if (cached) setData(JSON.parse(cached));

    try {
      const results = await Promise.all(
        symbols.map(async (sym) => {
          const res = await fetch(`/api/visionary-core?symbol=${sym}`, { cache: "no-store" });
          const json = await res.json();
          let price = json?.lastClose ?? json?.price ?? 0;
          const rsi = json?.rsi ?? 50;

          // ✅ ถ้าราคาไม่เจอ → ดึงจาก Yahoo quote API
          if (!price || price === 0) {
            try {
              const y = await fetch(`https://query1.finance.yahoo.com/v7/finance/quote?symbols=${sym}`);
              const yj = await y.json();
              price = yj?.quoteResponse?.result?.[0]?.regularMarketPrice ?? 0;
            } catch (e) {
              console.warn(`⚠️ Yahoo Fallback failed for ${sym}`);
            }
          }

          const signal = rsi > 55 ? "Buy" : rsi < 45 ? "Sell" : "Hold";
          if (price) logSignal(sym, signal, price);

          return {
            symbol: sym,
            company: companyMap[sym],
            price,
            rsi,
            signal
          };
        })
      );

      setData(results);
      sessionStorage.setItem("originx-cache", JSON.stringify(results));
    } catch (err) {
      console.warn("⚠️ Error loading stocks:", err);
    }
  }

  useEffect(() => {
    loadAll();
    const timer = setInterval(loadAll, 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="w-full bg-[#0b1220] min-h-screen text-gray-100 px-3 pt-3 font-sans">
      <h2 className="text-[22px] font-extrabold text-white flex items-center gap-2 mb-4 tracking-tight">
        🚀 OriginX Picks
      </h2>

      {data.length === 0 ? (
        <div className="text-center text-gray-400 py-10 italic">⏳ Loading data...</div>
      ) : (
        <div className="flex flex-col divide-y divide-gray-800/50">
          {data.map((r, i) => (
            <a
              key={i}
              href={`/analyze/${r.symbol}`}
              className="flex items-center justify-between py-[10px] hover:bg-[#111827]/40 transition-all"
            >
              {/* โลโก้ + ชื่อ */}
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full overflow-hidden border border-gray-700 flex items-center justify-center bg-[#0d111a]">
                  <img
                    src={`https://logo.clearbit.com/${logoMap[r.symbol]}`}
                    alt={r.symbol}
                    className="w-full h-full object-cover"
                    onError={(e) =>
                      (e.target.src = `https://placehold.co/48x48/0b1220/FFF?text=${r.symbol}`)
                    }
                  />
                </div>
                <div>
                  <div className="text-white text-[15px] font-extrabold tracking-wide leading-tight">
                    {r.symbol}
                  </div>
                  <div className="text-gray-400 text-[11px] font-medium truncate max-w-[160px] leading-snug">
                    {r.company}
                  </div>
                </div>
              </div>

              {/* ราคา + RSI + สัญญาณ */}
              <div className="text-right leading-tight font-mono min-w-[75px]">
                <div className="text-[15px] text-white font-black">
                  ${r.price ? r.price.toFixed(2) : "-"}
                </div>
                <div
                  className={`text-[13px] font-bold ${
                    r.rsi > 70
                      ? "text-red-400"
                      : r.rsi < 40
                      ? "text-blue-400"
                      : "text-emerald-400"
                  }`}
                >
                  {Math.round(r.rsi)}
                </div>
                <div
                  className={`text-[13px] font-extrabold ${
                    r.signal === "Buy"
                      ? "text-green-400"
                      : r.signal === "Sell"
                      ? "text-red-400"
                      : "text-yellow-400"
                  }`}
                >
                  {r.signal}
                </div>
              </div>
            </a>
          ))}
        </div>
      )}
    </section>
  );
}
