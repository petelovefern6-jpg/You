// ✅ /pages/api/news.js — Market news feed (was missing; NewsFeedPro & analyze page depended on this)
export default async function handler(req, res) {
  const { symbol = "", limit = 40 } = req.query;

  try {
    const url = symbol
      ? `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(symbol)}`
      : `https://query1.finance.yahoo.com/v1/finance/search?q=stock%20market`;

    const r = await fetch(url);
    const j = await r.json();

    const results = (j?.news || [])
      .slice(0, Number(limit))
      .map((n) => ({
        title: n.title,
        url: n.link,
        source: n.publisher || "Yahoo Finance",
        date: n.providerPublishTime
          ? new Date(n.providerPublishTime * 1000).toISOString()
          : new Date().toISOString(),
      }));

    // Both shapes are provided for backward compatibility with older callers
    res.status(200).json({ results, items: results });
  } catch (err) {
    console.error("❌ News fetch error:", err);
    res.status(200).json({ results: [], items: [] });
  }
}
