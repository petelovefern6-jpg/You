import { analyzeAI } from "@/utils/aiCore";

export default async function handler(req, res) {
  const { symbol } = req.query;
  if (!symbol) return res.status(400).json({ error: "missing symbol" });

  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=1d&range=6mo`;
    const r = await fetch(url);
    const d = await r.json();
    const chart = d.chart?.result?.[0];
    if (!chart) return res.status(404).json({ error: "no data" });

    const prices = chart.indicators.quote[0].close.filter((x) => typeof x === "number");
    const highs = chart.indicators.quote[0].high.filter((x) => typeof x === "number");
    const lows = chart.indicators.quote[0].low.filter((x) => typeof x === "number");
    const volumes = chart.indicators.quote[0].volume.filter((x) => typeof x === "number");

    const result = analyzeAI(prices, highs, lows, volumes);
    res.status(200).json({ symbol, ...result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
