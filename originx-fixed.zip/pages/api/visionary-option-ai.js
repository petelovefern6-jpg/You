// ✅ Visionary Option AI v3 — Real technical analysis (no random data)
export default async function handler(req, res) {
  const { symbol } = req.query;
  if (!symbol) return res.status(400).json({ error: "missing symbol" });

  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?range=6mo&interval=1d`;
    const r = await fetch(url);
    const j = await r.json();
    const result = j?.chart?.result?.[0];
    if (!result) throw new Error("No chart data");

    const prices = (result.indicators?.quote?.[0]?.close || []).filter(
      (x) => typeof x === "number"
    );
    if (prices.length < 20) throw new Error("Not enough price history");

    const lastClose = prices.at(-1);

    // === Real EMA ===
    const ema = (arr, period) => {
      const k = 2 / (period + 1);
      let prev = arr[0];
      for (let i = 1; i < arr.length; i++) prev = arr[i] * k + prev * (1 - k);
      return prev;
    };
    const ema20 = ema(prices.slice(-Math.min(20, prices.length)), 20);
    const ema50 = ema(prices.slice(-Math.min(50, prices.length)), 50);

    // === Real RSI (Wilder's smoothing) ===
    const period = 14;
    let gains = 0,
      losses = 0;
    for (let i = 1; i <= period && i < prices.length; i++) {
      const diff = prices[i] - prices[i - 1];
      if (diff >= 0) gains += diff;
      else losses -= diff;
    }
    let avgGain = gains / period;
    let avgLoss = losses / period || 0.0001;
    for (let i = period + 1; i < prices.length; i++) {
      const diff = prices[i] - prices[i - 1];
      avgGain = (avgGain * (period - 1) + Math.max(diff, 0)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.max(-diff, 0)) / period;
    }
    const rs = avgGain / (avgLoss || 0.0001);
    const rsi = 100 - 100 / (1 + rs);

    const trend =
      lastClose > ema20 && ema20 > ema50
        ? "Uptrend"
        : lastClose < ema20 && ema20 < ema50
        ? "Downtrend"
        : "Neutral";

    let score = 0;
    if (trend === "Uptrend") score += 2;
    if (trend === "Downtrend") score -= 2;
    if (rsi > 55) score += 1;
    if (rsi < 45) score -= 1;

    let action = "Hold";
    let confidence = 60;
    let reason = "รอการยืนยันเพิ่มเติม";
    let zone = "Neutral Zone";

    if (score >= 3) {
      action = "Buy";
      confidence = 90;
      reason = "แนวโน้มขาขึ้นแข็งแรง";
      zone = "Active Buy Zone";
    } else if (score <= -2) {
      action = "Sell";
      confidence = 80;
      reason = "แรงขายกดดัน";
      zone = "Caution Zone";
    }

    const topCall = {
      strike: +(lastClose * 1.05).toFixed(2),
      premium: +Math.max(0.2, lastClose * 0.05).toFixed(2),
      roi: +Math.max(0, confidence - 10).toFixed(0),
    };
    const topPut = {
      strike: +(lastClose * 0.95).toFixed(2),
      premium: +Math.max(0.15, lastClose * 0.04).toFixed(2),
      roi: +Math.max(0, 100 - confidence - 10).toFixed(0),
    };
    const target = +(lastClose * (action === "Buy" ? 1.08 : 0.95)).toFixed(2);

    res.status(200).json({
      symbol: symbol.toUpperCase(),
      signal: action,
      confidence,
      reason,
      zone,
      rsi: +rsi.toFixed(1),
      trend,
      target,
      lastClose,
      topCall,
      topPut,
      note: "คำนวณจาก EMA/RSI จริง ไม่ใช่คำแนะนำการลงทุน",
    });
  } catch (err) {
    console.error("❌ Option AI Error:", err);
    res.status(500).json({ error: "Option AI failed" });
  }
}
